
const express = require("express");
const validate = require("express-validation");
const myDb = "localhost/app";
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

//create admin token
const adminToken = "batman";
const router = express.Router();

const Company = require("./entities/company.js");
const User = require("./entities/user.js");
const Punches = require("./entities/punches.js");
const Validation = require("./validation");

router.use(bodyParser.json());


router.get("/companies", function (req, res) {
	Company.getCompanies(function (err, companies) {
		if (err) {
			return res.status(404).send({"err": "not found"});
		}
		var companyList = [];
		for (var i = 0; i < companies.length; i++) {
			var comp = { 
				name: companies[i].name,
				punches: companies[i].punches
			};
			companyList.push(comp);
		}
		return res.json(companyList);
	})
});

router.get("/companies/:id", function (req, res) {
	Company.getCompanyById(req.params.id, function (err, company) {
		if (err) {
			return res.status(404).send({ "err":"no company with the given id could be found" });
		}
		var returnObject = {
			name: company.name,
			punches: company.punches
		};
		return res.json(returnObject);
	})
});

router.post("/companies", validate(Validation.companyValidation), function (req, res) {
	var userToken = req.headers.authorization;
	if (userToken !== adminToken) {
		return res.status(401).send({ "err": "not authorized" });
	}
	var newCompany = req.body;
	Company.addCompany(newCompany, function (err, users) {
		if (err) {
			return res.status(404).send({ "err": "not found" });
		}
		return res.status(201).json(newCompany);
	});
});

router.get("/users", function (req, res) {
	User.getUsers(function (err, users) {
		if (err) {
			return res.status(404).json( {"err": "not found"} );
		}
		var userList = [];
		for (var i = 0; i < users.length; i++) {
			var tempUser = {
				name: users[i].name,
				gender: users[i].gender,

			};
			userList.push(tempUser);
		}
		return res.json(userList);
	})
});

router.post("/users", validate(Validation.userValidation), function (req, res) {
	var userToken = req.headers.authorization;
	
	if (userToken !== adminToken) {
		return res.status(401).json( {"err": "not authorized"} );
	}
	var newUser = req.body;
	User.addUser(newUser, function (err, users) {
		if (err) {
			return res.status(404).json(err);
		}
		return res.status(201).json(newUser.token);
	});
});


router.post("/my/punches", validate(Validation.punchValidation), function (req, res) {
	
	var userToken = req.headers.authorization;
	console.log("usertoken: " + userToken);
	var currentUserId;
	var companyId = req.body.company_id;

	User.getUserByToken(userToken, function (err, user) {
		if (err || user == null || user.length === 0) {
			return res.status(401).json({"err": "no user with the given token found"});
		}
		currentUserId = user._id;
		Company.getCompanyById(companyId, function (err, company) {
			if (err) {
				return res.status(404).json({ "err": "no company with the given id found" });
			}
			var newPunch = {
				company_id: companyId,
				user_id: currentUserId
			};
			
			Punches.addPunch(newPunch, function (err, punch) {
				if (err) {
					return res.status(404).json({ "err": "not found" });
				} 
				Punches.countPunchesForUser({ user_id: currentUserId, company_id: companyId, used: false }, function (err, punches) {
					if (err) {

						console.log(err);
						return;
					}
					if(punches.length === company.punches) {
						Punches.update(punches);
						return res.send({ discount: true });
					}
					return res.status(201).json({ "punch_id": punch._id });	
				});
			});	
		});
	});	
});

module.exports = router;


