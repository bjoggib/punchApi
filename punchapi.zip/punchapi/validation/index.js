exports.companyValidation = require("./companyValidation");
exports.userValidation = require("./userValidation");
exports.punchValidation = require("./punchValidation");